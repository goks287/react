const employeesData = [
  {
    id: 1,
    firstName: "Shailesh",
    lastName: "Jadav",
    email: "Shailesh@gmail.com",
    salary: "95000",
    date: "2015-01-01"
  },
  {
    id: 2,
    firstName: "Alice",
    lastName: "Johnson",
    email: "alice@gmail.com",
    salary: "8000",
    date: "2016-02-15"
  },
  {
    id: 3,
    firstName: "Bob",
    lastName: "Jones",
    email: "bob@gmail.com",
    salary: "7200",
    date: "2017-05-20"
  },
  {
    id: 4,
    firstName: "Emily",
    lastName: "Davis",
    email: "emily@gmail.com",
    salary: "10500",
    date: "2018-12-30"
   
  },
  {
    id: 5,
    firstName: "Michael",
    lastName: "Williams",
    email: "michael@gmail.com",
    salary: "9000",
    date: "2019-12-03"
  },
  {
    id: 6,
    firstName: "Sophia",
    lastName: "Miller",
    email: "sophia@gmail.com",
    salary: "8500",
    date: "2020-03-25"
  },
  {
    id: 7,
    firstName: "Daniel",
    lastName: "Brown",
    email: "daniel@gmail.com",
    salary: "9800",
    date: "2021-06-14"
  },
  {
    id: 8,
    firstName: "Olivia",
    lastName: "Anderson",
    email: "olivia@gmail.com",
    salary: "7500",
    date: "2022-10-05"
  },
  {
    id: 9,
    firstName: "William",
    lastName: "Taylor",
    email: "william@gmail.com",
    salary: "8200",
    date: "2023-02-18"
  },
  {
    id: 10,
    firstName: "Ava",
    lastName: "Moore",
    email: "ava@gmail.com",
    salary: "9100",
    date: "2024-07-07"
  }


];

  export { employeesData };